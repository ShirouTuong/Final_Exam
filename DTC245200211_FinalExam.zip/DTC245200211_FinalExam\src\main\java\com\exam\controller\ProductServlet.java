package com.exam.controller;

import com.exam.dao.ProductDAO;
import com.exam.model.Product;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * Controller Servlet điều phối toàn bộ các yêu cầu liên quan đến Sản phẩm.
 * Mapping URL: /, /products, /product
 */
@WebServlet(name = "ProductServlet", urlPatterns = {"/", "/products", "/product"})
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ProductDAO productDAO;

    @Override
    public void init() {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteProduct(request, response);
                    break;
                case "search":
                    searchProduct(request, response);
                    break;
                case "list":
                default:
                    listProducts(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "insert":
                    insertProduct(request, response);
                    break;
                case "update":
                    updateProduct(request, response);
                    break;
                default:
                    listProducts(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    /**
     * 1. Hiển thị danh sách tất cả sản phẩm
     */
    private void listProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Product> listProduct = productDAO.selectAllProducts();
        request.setAttribute("listProduct", listProduct);

        // Thông báo phản hồi nếu có từ tham số URL
        handleMessageParam(request);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-list.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Tìm kiếm sản phẩm theo tên
     */
    private void searchProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        List<Product> listProduct;
        if (keyword != null && !keyword.trim().isEmpty()) {
            listProduct = productDAO.searchProducts(keyword.trim());
            request.setAttribute("keyword", keyword.trim());
        } else {
            listProduct = productDAO.selectAllProducts();
        }
        request.setAttribute("listProduct", listProduct);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-list.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * 2. Hiển thị form thêm sản phẩm mới
     */
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("formAction", "insert");
        request.setAttribute("pageTitle", "Thêm Sản Phẩm Mới");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * 2. Xử lý lưu sản phẩm mới
     */
    private void insertProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");
        String quantityStr = request.getParameter("quantity");

        if (name == null || name.trim().isEmpty() || priceStr == null || quantityStr == null) {
            request.setAttribute("errorMessage", "Vui lòng nhập đầy đủ tất cả các trường thông tin!");
            request.setAttribute("formAction", "insert");
            request.setAttribute("pageTitle", "Thêm Sản Phẩm Mới");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
            dispatcher.forward(request, response);
            return;
        }

        try {
            double price = Double.parseDouble(priceStr.trim());
            int quantity = Integer.parseInt(quantityStr.trim());

            if (price < 0 || quantity < 0) {
                request.setAttribute("errorMessage", "Giá và số lượng phải lớn hơn hoặc bằng 0!");
                request.setAttribute("product", new Product(name.trim(), price, quantity));
                request.setAttribute("formAction", "insert");
                request.setAttribute("pageTitle", "Thêm Sản Phẩm Mới");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
                dispatcher.forward(request, response);
                return;
            }

            Product newProduct = new Product(name.trim(), price, quantity);
            boolean success = productDAO.insertProduct(newProduct);

            if (success) {
                response.sendRedirect(request.getContextPath() + "/products?msg=inserted");
            } else {
                response.sendRedirect(request.getContextPath() + "/products?err=insert_failed");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Giá tiền hoặc số lượng không đúng định dạng số hợp lệ!");
            request.setAttribute("formAction", "insert");
            request.setAttribute("pageTitle", "Thêm Sản Phẩm Mới");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
            dispatcher.forward(request, response);
        }
    }

    /**
     * 3. Hiển thị form cập nhật thông tin sản phẩm
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr == null || idStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/products?err=invalid_id");
            return;
        }

        try {
            int id = Integer.parseInt(idStr.trim());
            Product existingProduct = productDAO.selectProduct(id);
            if (existingProduct != null) {
                request.setAttribute("product", existingProduct);
                request.setAttribute("formAction", "update");
                request.setAttribute("pageTitle", "Cập Nhật Thông Tin Sản Phẩm");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
                dispatcher.forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/products?err=not_found");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/products?err=invalid_id");
        }
    }

    /**
     * 3. Xử lý cập nhật thông tin sản phẩm
     */
    private void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String idStr = request.getParameter("id");
        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");
        String quantityStr = request.getParameter("quantity");

        try {
            int id = Integer.parseInt(idStr.trim());
            double price = Double.parseDouble(priceStr.trim());
            int quantity = Integer.parseInt(quantityStr.trim());

            if (name == null || name.trim().isEmpty()) {
                request.setAttribute("errorMessage", "Tên sản phẩm không được để trống!");
                Product p = new Product(id, "", price, quantity);
                request.setAttribute("product", p);
                request.setAttribute("formAction", "update");
                request.setAttribute("pageTitle", "Cập Nhật Thông Tin Sản Phẩm");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
                dispatcher.forward(request, response);
                return;
            }

            if (price < 0 || quantity < 0) {
                request.setAttribute("errorMessage", "Giá và số lượng phải lớn hơn hoặc bằng 0!");
                Product p = new Product(id, name.trim(), price, quantity);
                request.setAttribute("product", p);
                request.setAttribute("formAction", "update");
                request.setAttribute("pageTitle", "Cập Nhật Thông Tin Sản Phẩm");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product-form.jsp");
                dispatcher.forward(request, response);
                return;
            }

            Product product = new Product(id, name.trim(), price, quantity);
            boolean success = productDAO.updateProduct(product);

            if (success) {
                response.sendRedirect(request.getContextPath() + "/products?msg=updated");
            } else {
                response.sendRedirect(request.getContextPath() + "/products?err=update_failed");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/products?err=invalid_data");
        }
    }

    /**
     * 4. Xóa sản phẩm
     */
    private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idStr = request.getParameter("id");
        if (idStr != null) {
            try {
                int id = Integer.parseInt(idStr.trim());
                boolean success = productDAO.deleteProduct(id);
                if (success) {
                    response.sendRedirect(request.getContextPath() + "/products?msg=deleted");
                } else {
                    response.sendRedirect(request.getContextPath() + "/products?err=delete_failed");
                }
                return;
            } catch (NumberFormatException ignored) {
            }
        }
        response.sendRedirect(request.getContextPath() + "/products?err=invalid_id");
    }

    /**
     * Xử lý hiển thị thông báo flash message qua tham số
     */
    private void handleMessageParam(HttpServletRequest request) {
        String msg = request.getParameter("msg");
        String err = request.getParameter("err");

        if ("inserted".equals(msg)) {
            request.setAttribute("successMessage", "Thêm sản phẩm mới thành công!");
        } else if ("updated".equals(msg)) {
            request.setAttribute("successMessage", "Cập nhật thông tin sản phẩm thành công!");
        } else if ("deleted".equals(msg)) {
            request.setAttribute("successMessage", "Đã xóa sản phẩm khỏi hệ thống!");
        }

        if ("not_found".equals(err)) {
            request.setAttribute("errorMessage", "Không tìm thấy sản phẩm yêu cầu!");
        } else if ("invalid_id".equals(err)) {
            request.setAttribute("errorMessage", "Mã sản phẩm không hợp lệ!");
        } else if ("insert_failed".equals(err)) {
            request.setAttribute("errorMessage", "Thêm sản phẩm thất bại! Vui lòng kiểm tra lại kết nối CSDL.");
        } else if ("update_failed".equals(err)) {
            request.setAttribute("errorMessage", "Cập nhật sản phẩm thất bại!");
        } else if ("delete_failed".equals(err)) {
            request.setAttribute("errorMessage", "Xóa sản phẩm thất bại!");
        }
    }
}
