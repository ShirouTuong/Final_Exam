package com.exam.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Lớp tiện ích quản lý kết nối Cơ sở dữ liệu MySQL thông qua JDBC.
 * Hỗ trợ nạp cấu hình từ db.properties hoặc sử dụng các giá trị mặc định.
 */
public class DBContext {

    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://localhost:3306/product_management?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Ho_Chi_Minh&characterEncoding=UTF-8";
    private static String username = "root";
    private static String password = "Matkhaumoi1@";

    static {
        try {
            // Đọc cấu hình từ file db.properties nếu có
            Properties props = new Properties();
            InputStream is = DBContext.class.getClassLoader().getResourceAsStream("db.properties");
            if (is != null) {
                props.load(is);
                if (props.getProperty("db.driver") != null) driver = props.getProperty("db.driver");
                if (props.getProperty("db.url") != null) url = props.getProperty("db.url");
                if (props.getProperty("db.username") != null) username = props.getProperty("db.username");
                if (props.getProperty("db.password") != null) password = props.getProperty("db.password");
            }
            // Đăng ký JDBC Driver
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("[DBContext] Cảnh báo khi tải cấu hình JDBC: " + e.getMessage());
        }
    }

    /**
     * Mở kết nối mới đến CSDL MySQL.
     * @return Connection đối tượng kết nối JDBC
     * @throws SQLException nếu kết nối thất bại
     */
    public static Connection getConnection() throws SQLException {
        try {
            // Đảm bảo driver được nạp
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Không tìm thấy MySQL JDBC Driver: " + driver, e);
        }
        return DriverManager.getConnection(url, username, password);
    }

    /**
     * Phương thức kiểm tra nhanh trạng thái kết nối Database.
     * @return true nếu kết nối thành công, false nếu thất bại
     */
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (Exception e) {
            System.err.println("[DBContext] Kiểm tra kết nối thất bại: " + e.getMessage());
            return false;
        }
    }

    // Các hàm getter/setter phục vụ việc đổi thông số động nếu cần
    public static String getUrl() {
        return url;
    }

    public static void setUrl(String url) {
        DBContext.url = url;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        DBContext.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        DBContext.password = password;
    }
}
