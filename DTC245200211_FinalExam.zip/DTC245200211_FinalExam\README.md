# BÀI KIỂM TRA CUỐI MODULE: PHÁT TRIỂN ỨNG DỤNG WEB VỚI JSP & SERVLET

* **Mã số sinh viên (MSSV):** `DTC245200211`
* **Tên file nộp bài:** `DTC245200211_FinalExam.zip`
* **Công nghệ sử dụng:** Java Servlet (Jakarta EE / Servlet 6.0), JSP & JSTL, JDBC, MySQL, Apache Tomcat 10.1, Maven, Bootstrap 5.

---

## 1. GIỚI THIỆU DỰ ÁN

Dự án là một hệ thống Web Quản lý Sản phẩm (Product Management System) được xây dựng theo kiến trúc **MVC (Model - View - Controller)** chuẩn mực, kết nối cơ sở dữ liệu MySQL thông qua JDBC.

### Các chức năng đã hiện thực (Đạt 100% yêu cầu):
1. **Hiển thị danh sách sản phẩm:**
   - Hiển thị tất cả sản phẩm trong database dưới dạng bảng giao diện hiện đại.
   - Mỗi sản phẩm gồm: `ID`, `Tên sản phẩm`, `Giá (VNĐ)`, `Số lượng`.
   - Có badge hiển thị trạng thái tồn kho (còn hàng, sắp hết hàng, hết hàng).
2. **Thêm sản phẩm mới:**
   - Cung cấp biểu mẫu (form) nhập: Tên sản phẩm, Giá, Số lượng với kiểm tra dữ liệu đầu vào.
   - Sau khi thêm thành công, chuyển hướng về danh sách và hiển thị thông báo thành công.
3. **Sửa thông tin sản phẩm:**
   - Cho phép chọn sản phẩm từ danh sách.
   - Biểu mẫu tự động điền các thông tin hiện có của sản phẩm để chỉnh sửa.
   - Sau khi cập nhật, lưu lại vào MySQL và chuyển về danh sách.
4. **Xóa sản phẩm:**
   - Cho phép người dùng xóa sản phẩm khỏi cơ sở dữ liệu.
   - **Có hộp thoại xác nhận (`confirm dialog`) trước khi xóa** để tránh thao tác nhầm lẫn.
5. **Chức năng mở rộng:**
   - Tìm kiếm sản phẩm theo tên ngay trên thanh công cụ.
   - Định dạng tiền tệ VNĐ chuẩn (`₫`).

---

## 2. CẤU TRÚC THƯ MỤC DỰ ÁN

```text
DTC245200211_FinalExam/
├── database/
│   └── init_database.sql          # File SQL khởi tạo CSDL & bảng products, dữ liệu mẫu
├── product_management.sql         # Bản sao SQL đặt tại thư mục gốc để tiện kiểm tra
├── pom.xml                        # File cấu hình Maven (quản lý thư viện & build WAR)
├── README.md                      # Hướng dẫn chi tiết cài đặt và sử dụng
└── src/
    └── main/
        ├── java/com/exam/
        │   ├── controller/
        │   │   └── ProductServlet.java   # Controller tiếp nhận & điều hướng request
        │   ├── dao/
        │   │   └── ProductDAO.java       # Xử lý CRUD kết nối MySQL qua JDBC
        │   ├── model/
        │   │   └── Product.java          # Đối tượng thực thể Sản phẩm
        │   └── util/
        │       └── DBContext.java        # Quản lý kết nối Database qua JDBC
        ├── resources/
        │   └── db.properties             # File cấu hình URL, User, Pass của MySQL
        └── webapp/
            ├── css/
            │   └── style.css             # CSS tùy biến giao diện
            ├── WEB-INF/
            │   ├── views/
            │   │   ├── product-list.jsp  # Giao diện danh sách sản phẩm
            │   │   └── product-form.jsp  # Giao diện thêm / sửa sản phẩm
            │   └── web.xml               # Bộ mô tả triển khai Web
            └── index.jsp                 # Trang chủ tự động chuyển hướng đến /products
```

---

## 3. HƯỚNG DẪN CÀI ĐẶT CƠ SỞ DỮ LIỆU BẰNG MYSQL WORKBENCH

1. Khởi động phần mềm **MySQL Workbench**.
2. Kết nối vào kết nối MySQL của bạn (ví dụ: `Local instance MySQL80` với user `root`).
3. Chọn menu: **File -> Open SQL Script...** (hoặc nhấn tổ hợp phím `Ctrl + Shift + O`).
4. Tìm và chọn file `product_management.sql` (hoặc `database/init_database.sql`) trong thư mục dự án.
5. Nhấn vào nút **Execute** (biểu tượng hình tia sét ⚡) để chạy script.
6. Script sẽ tự động:
   - Tạo cơ sở dữ liệu `product_management`.
   - Tạo bảng `products` với các cột: `id` (AUTO_INCREMENT, PRIMARY KEY), `name`, `price`, `quantity`.
   - Thêm 8 bản ghi sản phẩm mẫu đa dạng để kiểm tra.

---

## 4. CẤU HÌNH KẾT NỐI DATABASE

Nếu MySQL trên máy của bạn sử dụng tài khoản/mật khẩu khác với mặc định, bạn chỉ cần mở file:
`src/main/resources/db.properties`

```properties
db.driver=com.mysql.cj.jdbc.Driver
db.url=jdbc:mysql://localhost:3306/product_management?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Ho_Chi_Minh&characterEncoding=UTF-8
db.username=root
db.password=root
```
*(Thay đổi `db.username` và `db.password` cho phù hợp với tài khoản MySQL trên máy của bạn).*

---

## 5. HƯỚNG DẪN BUILD VÀ CHẠY DỰ ÁN TRÊN APACHE TOMCAT

### Cách 1: Đóng gói file `.war` bằng Maven và deploy vào Tomcat
1. Mở Terminal / PowerShell tại thư mục dự án `DTC245200211_FinalExam`.
2. Chạy lệnh:
   ```bash
   mvn clean package
   ```
3. Sau khi build thành công (`BUILD SUCCESS`), file đóng gói `DTC245200211_FinalExam.war` sẽ nằm trong thư mục `target/`.
4. Copy file `DTC245200211_FinalExam.war` vào thư mục `webapps` của Apache Tomcat (ví dụ: `apache-tomcat-10.1.60\webapps`).
5. Khởi động Tomcat bằng cách chạy `bin\startup.bat`.
6. Mở trình duyệt web truy cập:
   ```
   http://localhost:8080/DTC245200211_FinalExam/
   ```

### Cách 2: Chạy trực tiếp trong IDE (Eclipse / IntelliJ IDEA / VS Code)
1. Mở thư mục `DTC245200211_FinalExam` bằng IDE dưới dạng **Maven Project**.
2. Thêm server **Apache Tomcat 10.1** (hoặc Tomcat 10.x).
3. Thêm artifact `DTC245200211_FinalExam` vào Tomcat và nhấn **Run** / **Debug**.
4. Truy cập URL: `http://localhost:8080/DTC245200211_FinalExam/products`.

---

## 6. DANH SÁCH ENDPOINTS CỦA HỆ THỐNG

| Chức năng | Phương thức HTTP | URL / Tham số | Mô tả |
| :--- | :---: | :--- | :--- |
| Danh sách sản phẩm | `GET` | `/products` hoặc `/` | Hiển thị bảng toàn bộ sản phẩm |
| Tìm kiếm sản phẩm | `GET` | `/products?action=search&keyword=...` | Tìm sản phẩm theo tên |
| Form thêm mới | `GET` | `/products?action=new` | Hiển thị biểu mẫu nhập thông tin |
| Lưu thêm mới | `POST` | `/products` (action=insert) | Thêm sản phẩm vào CSDL MySQL |
| Form sửa sản phẩm | `GET` | `/products?action=edit&id={id}` | Hiển thị form có dữ liệu sản phẩm cũ |
| Lưu cập nhật | `POST` | `/products` (action=update) | Cập nhật thông tin vào CSDL MySQL |
| Xóa sản phẩm | `GET` | `/products?action=delete&id={id}` | Xóa sản phẩm (sau khi xác nhận) |
