<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${pageTitle} - Quản Lý Sản Phẩm</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="${pageContext.request.contextPath}/css/style.css" rel="stylesheet">
</head>
<body>

    <!-- Header / Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="${pageContext.request.contextPath}/products">
                <i class="bi bi-box-seam-fill fs-4"></i>
                <span>Product Management System</span>
            </a>
            <span class="navbar-text text-white-50 d-none d-md-block">
                MSSV: DTC245200211 | Bài Kiểm Tra Cuối Module
            </span>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="container main-container">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-md-9">

                <!-- Thông báo lỗi nếu có -->
                <c:if test="${not empty errorMessage}">
                    <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm mb-4" role="alert">
                        <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                        <div>${errorMessage}</div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </c:if>

                <!-- Form Card -->
                <div class="card custom-card">
                    <div class="custom-card-header d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="mb-1 fw-bold text-primary">
                                <c:choose>
                                    <c:when test="${product != null && product.id > 0}">
                                        <i class="bi bi-pencil-square me-2"></i>Chỉnh Sửa Thông Tin Sản Phẩm
                                    </c:when>
                                    <c:otherwise>
                                        <i class="bi bi-plus-circle me-2"></i>Thêm Sản Phẩm Mới
                                    </c:otherwise>
                                </c:choose>
                            </h4>
                            <p class="text-muted small mb-0">Điền đầy đủ thông tin bên dưới và nhấn Lưu</p>
                        </div>
                        <a href="${pageContext.request.contextPath}/products" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-arrow-left me-1"></i>Danh sách
                        </a>
                    </div>

                    <div class="card-body p-4">
                        <form action="${pageContext.request.contextPath}/products" method="post" id="productForm" class="needs-validation">
                            <!-- Action ẩn xác định insert hoặc update -->
                            <input type="hidden" name="action" value="${formAction}">

                            <!-- Nếu là sửa thì gửi kèm ID -->
                            <c:if test="${product != null && product.id > 0}">
                                <input type="hidden" name="id" value="${product.id}">
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-semibold">MÃ SẢN PHẨM (ID):</label>
                                    <input type="text" class="form-control bg-light" value="#${product.id}" readonly disabled>
                                </div>
                            </c:if>

                            <!-- Tên sản phẩm -->
                            <div class="mb-3">
                                <label for="name" class="form-label fw-semibold">
                                    Tên Sản Phẩm <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-tag-fill"></i></span>
                                    <input type="text" class="form-control" id="name" name="name"
                                           placeholder="Ví dụ: Laptop Dell XPS 15..."
                                           value="${product != null ? product.name : ''}" required autofocus>
                                </div>
                                <div class="form-text">Nhập tên đầy đủ của sản phẩm.</div>
                            </div>

                            <!-- Giá sản phẩm -->
                            <div class="mb-3">
                                <label for="price" class="form-label fw-semibold">
                                    Giá Bán (VNĐ) <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
                                    <input type="number" step="1000" min="0" class="form-control" id="price" name="price"
                                           placeholder="Ví dụ: 15000000"
                                           value="${product != null ? product.price : ''}" required>
                                    <span class="input-group-text">₫</span>
                                </div>
                                <div class="form-text">Giá bán là số không âm.</div>
                            </div>

                            <!-- Số lượng trong kho -->
                            <div class="mb-4">
                                <label for="quantity" class="form-label fw-semibold">
                                    Số Lượng Trong Kho <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-boxes"></i></span>
                                    <input type="number" min="0" step="1" class="form-control" id="quantity" name="quantity"
                                           placeholder="Ví dụ: 50"
                                           value="${product != null ? product.quantity : ''}" required>
                                    <span class="input-group-text">chiếc</span>
                                </div>
                                <div class="form-text">Số lượng sản phẩm nhập kho (tối thiểu 0).</div>
                            </div>

                            <!-- Nhóm nút bấm -->
                            <div class="d-flex justify-content-end gap-2 pt-2 border-top">
                                <a href="${pageContext.request.contextPath}/products" class="btn btn-light px-4">
                                    <i class="bi bi-x-circle me-1"></i>Hủy bỏ
                                </a>
                                <button type="submit" class="btn btn-primary px-4 shadow-sm">
                                    <i class="bi bi-check2-circle me-1"></i>
                                    <c:choose>
                                        <c:when test="${product != null && product.id > 0}">
                                            Cập Nhật Sản Phẩm
                                        </c:when>
                                        <c:otherwise>
                                            Lưu Sản Phẩm Mới
                                        </c:otherwise>
                                    </c:choose>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer-custom text-center">
        <div class="container">
            <p class="mb-0">© 2026 Bài Kiểm Tra Cuối Module - Phát Triển Ứng Dụng Web với JSP &amp; Servlet</p>
            <p class="small mb-0 text-muted">MSSV: DTC245200211 | Chạy trên nền tảng Apache Tomcat &amp; MySQL</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
