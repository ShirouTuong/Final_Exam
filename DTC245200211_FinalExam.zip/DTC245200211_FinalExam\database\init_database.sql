-- ====================================================================
-- BÀI KIỂM TRA CUỐI MODULE: PHÁT TRIỂN ỨNG DỤNG WEB VỚI JSP & SERVLET
-- HỌ VÀ TÊN / MSSV: DTC245200211
-- ĐỀ TÀI: HỆ THỐNG QUẢN LÝ SẢN PHẨM (PRODUCT MANAGEMENT)
-- ====================================================================

-- 1. Tạo Database riêng cho dự án
CREATE DATABASE IF NOT EXISTS `product_management`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `product_management`;

-- 2. Xóa bảng cũ nếu đã tồn tại để tránh xung đột
DROP TABLE IF EXISTS `products`;

-- 3. Tạo bảng `products` theo đúng yêu cầu đề bài:
--    id (PRIMARY KEY, AUTO_INCREMENT), name, price, quantity
CREATE TABLE `products` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Mã sản phẩm (Tự tăng)',
    `name` VARCHAR(255) NOT NULL COMMENT 'Tên sản phẩm',
    `price` DOUBLE NOT NULL COMMENT 'Giá sản phẩm',
    `quantity` INT NOT NULL COMMENT 'Số lượng sản phẩm trong kho'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Chèn dữ liệu mẫu ban đầu để kiểm tra giao diện hiển thị
INSERT INTO `products` (`name`, `price`, `quantity`) VALUES
('Laptop Dell XPS 15 9530', 45990000, 12),
('iPhone 15 Pro Max 256GB', 29490000, 25),
('Màn hình LG 27 inch 4K UHD 27UP850', 8990000, 18),
('Bàn phím cơ AKKO 3087 v2 Silent', 1250000, 30),
('Chuột không dây Logitech MX Master 3S', 2290000, 45),
('Tai nghe Sony WH-1000XM5', 6790000, 15),
('iPad Pro M4 11 inch 256GB Wifi', 28990000, 8),
('Loa Bluetooth Marshall Acton III', 6290000, 20);

-- 5. Truy vấn kiểm tra dữ liệu
SELECT * FROM `products`;
