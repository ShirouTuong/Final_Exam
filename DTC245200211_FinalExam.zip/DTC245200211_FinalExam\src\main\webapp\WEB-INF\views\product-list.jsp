<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Sản Phẩm - JSP & Servlet</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="${pageContext.request.contextPath}/css/style.css" rel="stylesheet">
</head>
<body>

    <!-- Header / Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="${pageContext.request.contextPath}/products">
                <i class="bi bi-box-seam-fill fs-4"></i>
                <span>Product Management System</span>
            </a>
            <span class="navbar-text text-white-50 d-none d-md-block">
                MSSV: DTC245200211 | Bài Kiểm Tra Cuối Module
            </span>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container main-container">

        <!-- Thông báo thành công (Success Alert) -->
        <c:if test="${not empty successMessage}">
            <div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm" role="alert">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <div><strong>Thành công!</strong> ${successMessage}</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </c:if>

        <!-- Thông báo lỗi (Error Alert) -->
        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2 shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                <div><strong>Thông báo lỗi:</strong> ${errorMessage}</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </c:if>

        <!-- Card Container -->
        <div class="card custom-card">
            <div class="custom-card-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div>
                    <h4 class="mb-1 fw-bold text-primary">
                        <i class="bi bi-list-check me-2"></i>Danh Sách Sản Phẩm
                    </h4>
                    <p class="text-muted small mb-0">Quản lý kho hàng và thông tin sản phẩm cơ bản</p>
                </div>

                <div class="d-flex flex-wrap gap-2">
                    <!-- Form Tìm kiếm -->
                    <form action="${pageContext.request.contextPath}/products" method="get" class="d-flex">
                        <input type="hidden" name="action" value="search">
                        <div class="input-group">
                            <input type="text" name="keyword" class="form-control form-control-sm"
                                   placeholder="Tìm tên sản phẩm..." value="${keyword}">
                            <button class="btn btn-outline-primary btn-sm" type="submit" title="Tìm kiếm">
                                <i class="bi bi-search"></i>
                            </button>
                            <c:if test="${not empty keyword}">
                                <a href="${pageContext.request.contextPath}/products" class="btn btn-outline-secondary btn-sm" title="Xóa tìm kiếm">
                                    <i class="bi bi-x-lg"></i>
                                </a>
                            </c:if>
                        </div>
                    </form>

                    <!-- Nút Thêm mới sản phẩm -->
                    <a href="${pageContext.request.contextPath}/products?action=new" class="btn btn-primary btn-sm d-flex align-items-center gap-2 px-3 shadow-sm">
                        <i class="bi bi-plus-circle-fill"></i>
                        <span>Thêm Sản Phẩm Mới</span>
                    </a>
                </div>
            </div>

            <div class="card-body p-0">
                <!-- Bảng hiển thị danh sách sản phẩm -->
                <div class="table-responsive">
                    <table class="table table-hover table-custom align-middle">
                        <thead>
                            <tr>
                                <th style="width: 80px;" class="text-center">ID</th>
                                <th>Tên Sản Phẩm</th>
                                <th style="width: 200px;">Giá (VNĐ)</th>
                                <th style="width: 140px;" class="text-center">Số Lượng</th>
                                <th style="width: 180px;" class="text-center">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:choose>
                                <c:when test="${not empty listProduct}">
                                    <c:forEach var="product" items="${listProduct}">
                                        <tr>
                                            <td class="text-center fw-semibold text-secondary">#${product.id}</td>
                                            <td>
                                                <div class="fw-semibold text-dark">${product.name}</div>
                                            </td>
                                            <td>
                                                <span class="price-tag">
                                                    <fmt:formatNumber value="${product.price}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <c:choose>
                                                    <c:when test="${product.quantity > 10}">
                                                        <span class="badge bg-success-subtle text-success border border-success-subtle badge-stock">
                                                            <i class="bi bi-check2-circle me-1"></i>${product.quantity} cái
                                                        </span>
                                                    </c:when>
                                                    <c:when test="${product.quantity > 0}">
                                                        <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle badge-stock">
                                                            <i class="bi bi-exclamation-circle me-1"></i>${product.quantity} cái
                                                        </span>
                                                    </c:when>
                                                    <c:otherwise>
                                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle badge-stock">
                                                            Hết hàng
                                                        </span>
                                                    </c:otherwise>
                                                </c:choose>
                                            </td>
                                            <td class="text-center">
                                                <div class="d-inline-flex gap-2">
                                                    <!-- Nút Sửa -->
                                                    <a href="${pageContext.request.contextPath}/products?action=edit&id=${product.id}"
                                                       class="btn btn-outline-primary btn-action" title="Chỉnh sửa thông tin">
                                                        <i class="bi bi-pencil-square"></i>
                                                        <span>Sửa</span>
                                                    </a>

                                                    <!-- Nút Xóa (Có xác nhận JavaScript) -->
                                                    <a href="${pageContext.request.contextPath}/products?action=delete&id=${product.id}"
                                                       onclick="return confirmDelete('${product.id}', '${product.name}');"
                                                       class="btn btn-outline-danger btn-action" title="Xóa sản phẩm">
                                                        <i class="bi bi-trash3-fill"></i>
                                                        <span>Xóa</span>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </c:when>
                                <c:otherwise>
                                    <tr>
                                        <td colspan="5" class="text-center py-5">
                                            <div class="text-muted">
                                                <i class="bi bi-inbox fs-1 d-block mb-3 text-secondary opacity-50"></i>
                                                <p class="h6 mb-2">Chưa có sản phẩm nào trong hệ thống</p>
                                                <p class="small text-muted mb-3">Vui lòng bấm nút bên dưới để tạo sản phẩm mới đầu tiên</p>
                                                <a href="${pageContext.request.contextPath}/products?action=new" class="btn btn-outline-primary btn-sm">
                                                    <i class="bi bi-plus-lg me-1"></i>Thêm sản phẩm mới ngay
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                </c:otherwise>
                            </c:choose>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Card Footer đếm số lượng -->
            <div class="card-footer bg-light py-2 px-3 text-muted small d-flex justify-content-between align-items-center">
                <span>Tổng số sản phẩm hiển thị: <strong>${listProduct != null ? listProduct.size() : 0}</strong></span>
                <span>Hệ thống Quản lý Sản phẩm - JSP/Servlet &amp; JDBC</span>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <footer class="footer-custom text-center">
        <div class="container">
            <p class="mb-0">© 2026 Bài Kiểm Tra Cuối Module - Phát Triển Ứng Dụng Web với JSP &amp; Servlet</p>
            <p class="small mb-0 text-muted">MSSV: DTC245200211 | Chạy trên nền tảng Apache Tomcat &amp; MySQL</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- JavaScript Xác nhận trước khi xóa (Yêu cầu chức năng 4) -->
    <script>
        function confirmDelete(id, productName) {
            return confirm("XÁC NHẬN XÓA SẢN PHẨM:\n\nBạn có chắc chắn muốn xóa sản phẩm:\n[#" + id + "] " + productName + " ?\n\nHành động này không thể hoàn tác!");
        }
    </script>
</body>
</html>
