package com.exam.model;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Model class đại diện cho đối tượng Sản phẩm (Product).
 * Tương ứng với bảng `products` trong cơ sở dữ liệu MySQL:
 * - id: INT (PRIMARY KEY, AUTO_INCREMENT)
 * - name: VARCHAR(255)
 * - price: DOUBLE
 * - quantity: INT
 */
public class Product implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private double price;
    private int quantity;

    // Constructor mặc định
    public Product() {
    }

    // Constructor dùng khi thêm sản phẩm mới (chưa có ID)
    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Constructor đầy đủ (khi truy vấn hoặc cập nhật sản phẩm đã có ID)
    public Product(int id, String name, double price, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters và Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Phương thức tiện ích định dạng giá tiền sang chuẩn tiền tệ Việt Nam (VNĐ)
     * Ví dụ: 1250000 -> 1.250.000 ₫
     */
    public String getFormattedPrice() {
        try {
            Locale vnLocale = Locale.forLanguageTag("vi-VN");
            NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(vnLocale);
            return currencyFormatter.format(this.price);
        } catch (Exception e) {
            return String.format("%,.0f VNĐ", this.price);
        }
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }
}
